export interface AnimeShow {
  id: string;
  title: string;
  episode: number;
  totalEpisodes: number | null;
  airDay: string;
  airTime: string;
  image: string;
  genres: string[];
  studio: string;
  season: string;
  year: number;
  description: string;
}

export const daysOfWeek = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
];

export const animeData: AnimeShow[] = [
  {
    id: "1",
    title: "Cosmic Nexus",
    episode: 14,
    totalEpisodes: 24,
    airDay: "Monday",
    airTime: "22:30",
    image: "https://placehold.co/600x400/3b1c6f/ffffff?text=Cosmic+Nexus",
    genres: ["Sci-Fi", "Adventure"],
    studio: "Stellar Studios",
    season: "Summer",
    year: 2025,
    description: "In a distant future, humanity has colonized the stars. Follow the crew of the starship Nexus as they encounter alien civilizations and cosmic anomalies."
  },
  {
    id: "2",
    title: "Neon Hunters",
    episode: 8,
    totalEpisodes: 12,
    airDay: "Monday",
    airTime: "23:00",
    image: "https://placehold.co/600x400/00a4bc/ffffff?text=Neon+Hunters",
    genres: ["Cyberpunk", "Action"],
    studio: "Digital Dreams",
    season: "Summer",
    year: 2025,
    description: "In a cyberpunk metropolis, a group of bounty hunters track down dangerous criminals while navigating corporate conspiracies and digital warfare."
  },
  {
    id: "3",
    title: "Spirit Blade",
    episode: 20,
    totalEpisodes: 24,
    airDay: "Tuesday",
    airTime: "21:00",
    image: "https://placehold.co/600x400/e62fbc/ffffff?text=Spirit+Blade",
    genres: ["Fantasy", "Action"],
    studio: "Mystic Animation",
    season: "Spring",
    year: 2025,
    description: "A young swordsman inherits an ancient blade with the power to slay spiritual entities, drawing him into a conflict between the mortal and spirit worlds."
  },
  {
    id: "4",
    title: "Academy of Wonders",
    episode: 6,
    totalEpisodes: 13,
    airDay: "Wednesday",
    airTime: "19:30",
    image: "https://placehold.co/600x400/4264fb/ffffff?text=Academy+of+Wonders",
    genres: ["Fantasy", "School"],
    studio: "Enchanted Works",
    season: "Summer",
    year: 2025,
    description: "At a prestigious academy for magical studies, students learn to harness the elements and ancient arts while uncovering the school's mysterious past."
  },
  {
    id: "5",
    title: "Mecha Revolution",
    episode: 17,
    totalEpisodes: 26,
    airDay: "Thursday",
    airTime: "22:00",
    image: "https://placehold.co/600x400/00d5c8/ffffff?text=Mecha+Revolution",
    genres: ["Mecha", "Sci-Fi"],
    studio: "Robotic Dreams",
    season: "Spring",
    year: 2025,
    description: "In a world dominated by giant mechanical suits, pilots from opposing factions battle for supremacy while questioning the true purpose behind the conflict."
  },
  {
    id: "6",
    title: "Shadow Assassin",
    episode: 11,
    totalEpisodes: 22,
    airDay: "Friday",
    airTime: "23:30",
    image: "https://placehold.co/600x400/731abc/ffffff?text=Shadow+Assassin",
    genres: ["Action", "Thriller"],
    studio: "Midnight Productions",
    season: "Summer",
    year: 2025,
    description: "An elite assassin who can manipulate shadows takes on high-profile targets while being pursued by both law enforcement and rival assassin guilds."
  },
  {
    id: "7",
    title: "Love Under Neon Lights",
    episode: 9,
    totalEpisodes: 12,
    airDay: "Saturday",
    airTime: "20:00",
    image: "https://placehold.co/600x400/ff3399/ffffff?text=Love+Under+Neon+Lights",
    genres: ["Romance", "Drama"],
    studio: "HeartBeat Animation",
    season: "Summer",
    year: 2025,
    description: "In a city that never sleeps, two young adults from different backgrounds navigate their budding romance amidst career challenges and family expectations."
  },
  {
    id: "8",
    title: "Quantum Pirates",
    episode: 3,
    totalEpisodes: null,
    airDay: "Saturday",
    airTime: "21:30",
    image: "https://placehold.co/600x400/19d0d4/ffffff?text=Quantum+Pirates",
    genres: ["Adventure", "Sci-Fi"],
    studio: "Dimension X",
    season: "Summer",
    year: 2025,
    description: "A crew of interdimensional pirates travels between realities, stealing valuable artifacts and evading the multiverse police force determined to catch them."
  },
  {
    id: "9",
    title: "Mystic Knights",
    episode: 16,
    totalEpisodes: 24,
    airDay: "Sunday",
    airTime: "18:00",
    image: "https://placehold.co/600x400/c100c1/ffffff?text=Mystic+Knights",
    genres: ["Fantasy", "Action"],
    studio: "Legend Animation",
    season: "Spring",
    year: 2025,
    description: "Five warriors chosen by the elemental spirits must unite to defend their realm from an ancient evil that threatens to consume all life."
  },
  {
    id: "10",
    title: "Digital Detectives",
    episode: 7,
    totalEpisodes: 12,
    airDay: "Sunday",
    airTime: "21:00",
    image: "https://placehold.co/600x400/00a9e0/ffffff?text=Digital+Detectives",
    genres: ["Mystery", "Sci-Fi"],
    studio: "Cyber Arts",
    season: "Summer",
    year: 2025,
    description: "In a world where crimes increasingly take place in virtual reality, a specialized police unit investigates cases that blur the line between the digital and physical worlds."
  }
];