import { ReactNode } from "react";
import { Header } from "./Header";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">{children}</main>
      <footer className="py-6 text-center border-t border-border/40">
        <div className="container">
          <p className="text-sm text-muted-foreground">
            © 2025 <span className="neon-text-purple">XenomnextT</span> <span className="neon-text-blue">Anime</span>. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}