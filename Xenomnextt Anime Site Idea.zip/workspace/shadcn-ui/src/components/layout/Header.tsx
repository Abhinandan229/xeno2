import { useState } from "react";
import { Button } from "@/components/ui/button";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  return (
    <header className="sticky top-0 z-40 border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center space-x-2">
            <span className="text-2xl font-bold neon-text-purple">XenomnextT</span>
            <span className="text-2xl font-bold neon-text-blue">Anime</span>
          </div>
        </div>

        {/* Mobile Menu Button */}
        <Button 
          variant="ghost" 
          className="md:hidden" 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle Menu"
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor" 
            className="h-6 w-6"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} 
            />
          </svg>
        </Button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Button variant="ghost" className="neon-text-blue">Today</Button>
          <Button variant="ghost" className="neon-text-pink">This Week</Button>
          <Button variant="ghost" className="neon-text-purple">Schedule</Button>
          <Button variant="outline" className="neon-border">Sign Up</Button>
        </nav>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="absolute top-16 left-0 right-0 bg-background border-b border-border/40 md:hidden">
            <div className="flex flex-col space-y-2 p-4">
              <Button variant="ghost" className="neon-text-blue justify-start">Today</Button>
              <Button variant="ghost" className="neon-text-pink justify-start">This Week</Button>
              <Button variant="ghost" className="neon-text-purple justify-start">Schedule</Button>
              <Button variant="outline" className="neon-border justify-start">Sign Up</Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}