import { AnimeShow } from "@/data/animeData";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface AnimeCardProps {
  anime: AnimeShow;
  variant?: "blue" | "pink" | "purple";
}

export function AnimeCard({ anime, variant = "blue" }: AnimeCardProps) {
  const neonBorderClass = variant === "blue" 
    ? "neon-border" 
    : variant === "pink" 
      ? "neon-border-pink" 
      : "neon-border-purple";
  
  const neonTextClass = variant === "blue" 
    ? "neon-text-blue" 
    : variant === "pink" 
      ? "neon-text-pink" 
      : "neon-text-purple";
  
  return (
    <Card className={`anime-card ${neonBorderClass} backdrop-blur-sm bg-card/80`}>
      <CardHeader className="p-4 pb-2">
        <div className="flex flex-col gap-1">
          <div className="aspect-video overflow-hidden rounded-md">
            <img
              src={anime.image}
              alt={anime.title}
              className="object-cover w-full h-full transition-transform duration-300 hover:scale-110"
            />
          </div>
          <div className="mt-2">
            <h3 className={`font-bold text-xl ${neonTextClass}`}>{anime.title}</h3>
            <div className="flex items-center gap-2 text-sm mt-1">
              <span className="text-muted-foreground">EP {anime.episode}</span>
              {anime.totalEpisodes && (
                <span className="text-muted-foreground">/ {anime.totalEpisodes}</span>
              )}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="flex flex-wrap gap-1 mb-2">
          {anime.genres.map((genre) => (
            <Badge key={genre} variant="secondary" className="text-xs">
              {genre}
            </Badge>
          ))}
        </div>
        <div className="text-sm text-muted-foreground mt-2">
          <div className="flex justify-between">
            <span>{anime.airDay}</span>
            <span className={neonTextClass}>{anime.airTime}</span>
          </div>
          <div className="mt-1">
            <span>{anime.studio}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}