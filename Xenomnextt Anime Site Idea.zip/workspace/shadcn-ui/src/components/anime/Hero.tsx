export function Hero() {
  return (
    <div className="relative overflow-hidden">
      <div className="container py-12 md:py-24 flex flex-col items-center text-center">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,rgba(103,0,190,0.15),rgba(0,163,255,0.05))]"></div>
        
        <div className="max-w-3xl space-y-6 neon-glow">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
            <span className="neon-text-purple">XenomnextT</span> <span className="neon-text-blue">Anime</span>
          </h1>
          
          <p className="text-xl text-muted-foreground">
            Your ultimate anime schedule tracker with a neon aesthetic
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <button className="px-6 py-3 rounded-md bg-primary/90 text-primary-foreground neon-glow hover:bg-primary/80 transition-all">
              Today's Schedule
            </button>
            <button className="px-6 py-3 rounded-md bg-muted/80 text-foreground hover:bg-muted/60 transition-all">
              Explore All Shows
            </button>
          </div>
        </div>
        
        <div className="w-full mt-16 relative">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200%] aspect-square rounded-full -z-10 bg-gradient-to-r from-secondary/20 via-primary/20 to-accent/20 blur-3xl"></div>
          <div className="grid grid-cols-4 md:grid-cols-8 gap-6 opacity-80">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="aspect-[3/4] rounded-lg overflow-hidden"
                style={{
                  background: `linear-gradient(${45 * i}deg, hsl(var(--neon-blue) / 0.3), hsl(var(--neon-purple) / 0.3), hsl(var(--neon-pink) / 0.3))`,
                  transform: `translateY(${i % 2 === 0 ? "10%" : "0"})`,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}