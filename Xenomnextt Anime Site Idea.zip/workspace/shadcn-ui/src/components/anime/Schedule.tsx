import { useState } from "react";
import { daysOfWeek, animeData, AnimeShow } from "@/data/animeData";
import { AnimeCard } from "./AnimeCard";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function Schedule() {
  const [activeDay, setActiveDay] = useState<string>(getCurrentDay());
  
  function getCurrentDay(): string {
    const today = new Date().getDay();
    // Convert from JS day (0 = Sunday) to our format (Sunday is at index 6)
    const dayIndex = today === 0 ? 6 : today - 1;
    return daysOfWeek[dayIndex];
  }
  
  const getAnimeByDay = (day: string): AnimeShow[] => {
    return animeData.filter(anime => anime.airDay === day);
  };
  
  // Get a variant color based on the anime id to alternate colors
  const getVariant = (id: string): "blue" | "pink" | "purple" => {
    const num = parseInt(id);
    if (num % 3 === 0) return "pink";
    if (num % 3 === 1) return "blue";
    return "purple";
  };

  return (
    <div className="container py-8">
      <h2 className="text-3xl font-bold mb-6 text-center neon-text-purple">Weekly Anime Schedule</h2>
      
      {/* Day selector for small screens */}
      <div className="md:hidden mb-6">
        <select 
          className="w-full p-2 bg-muted border border-border rounded-md text-foreground"
          value={activeDay}
          onChange={(e) => setActiveDay(e.target.value)}
        >
          {daysOfWeek.map(day => (
            <option key={day} value={day}>{day}</option>
          ))}
        </select>
      </div>
      
      {/* Tab view for larger screens */}
      <Tabs 
        defaultValue={activeDay} 
        className="hidden md:block"
        onValueChange={setActiveDay}
        value={activeDay}
      >
        <TabsList className="w-full mb-6 grid grid-cols-7 bg-muted/20 neon-glow">
          {daysOfWeek.map(day => (
            <TabsTrigger 
              key={day} 
              value={day}
              className={`text-foreground data-[state=active]:neon-text-blue`}
            >
              {day}
            </TabsTrigger>
          ))}
        </TabsList>

        {daysOfWeek.map(day => (
          <TabsContent key={day} value={day} className="mt-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {getAnimeByDay(day).length > 0 ? (
                getAnimeByDay(day).map(anime => (
                  <AnimeCard 
                    key={anime.id} 
                    anime={anime} 
                    variant={getVariant(anime.id)}
                  />
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <p className="text-muted-foreground text-lg">No anime scheduled for {day}</p>
                </div>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>
      
      {/* Mobile view for the selected day */}
      <div className="md:hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {getAnimeByDay(activeDay).length > 0 ? (
            getAnimeByDay(activeDay).map(anime => (
              <AnimeCard 
                key={anime.id} 
                anime={anime} 
                variant={getVariant(anime.id)}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground text-lg">No anime scheduled for {activeDay}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}