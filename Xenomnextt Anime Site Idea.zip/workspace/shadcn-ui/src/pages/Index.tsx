import { Layout } from "@/components/layout/Layout";
import { Hero } from "@/components/anime/Hero";
import { Schedule } from "@/components/anime/Schedule";

export default function IndexPage() {
  return (
    <Layout>
      <Hero />
      <Schedule />
      
      {/* Featured Section */}
      <section className="container py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold neon-text-pink mb-2">Why XenomnextT Anime?</h2>
          <p className="text-muted-foreground">The ultimate anime schedule tracker with neon aesthetics</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center text-center p-6 rounded-lg bg-muted/20 neon-glow">
            <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="neon-text-purple">
                <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                <line x1="16" x2="16" y1="2" y2="6" />
                <line x1="8" x2="8" y1="2" y2="6" />
                <line x1="3" x2="21" y1="10" y2="10" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2 neon-text-purple">Weekly Schedule</h3>
            <p className="text-muted-foreground">Never miss an episode with our organized weekly schedule</p>
          </div>
          
          <div className="flex flex-col items-center text-center p-6 rounded-lg bg-muted/20 neon-glow">
            <div className="h-16 w-16 rounded-full bg-secondary/20 flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="neon-text-blue">
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2 neon-text-blue">Show Details</h3>
            <p className="text-muted-foreground">Detailed information about each anime including episode counts and studios</p>
          </div>
          
          <div className="flex flex-col items-center text-center p-6 rounded-lg bg-muted/20 neon-glow">
            <div className="h-16 w-16 rounded-full bg-accent/20 flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="neon-text-pink">
                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2 neon-text-pink">Personalized</h3>
            <p className="text-muted-foreground">Create an account to customize your experience and track your shows</p>
          </div>
        </div>
      </section>
    </Layout>
  );
}
